from django.apps import AppConfig


class MysqlinventoryConfig(AppConfig):
    name = 'mysqlinventory'
